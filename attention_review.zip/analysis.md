# Analysis

## Layer 8, Head 11

This attention head appears to capture a relationship between determiners and the head nouns of noun phrases. In both examples, the first token "the" attends strongly to the subject noun ("dog" or "student"), even though an adjective occurs between the determiner and the noun. This suggests that the head may help connect words belonging to the same noun phrase. The pattern is not universal across all tokens, and attention to special tokens is also visible, so this is a tentative interpretation based on the two diagrams.

Example Sentences:
- The little dog chased the [MASK].
- The young student opened the [MASK].

## Layer 1, Head 4

This attention head appears to favor preceding tokens, often the immediately preceding word. For example, in the first sentence, "chased" attends noticeably to "dog"; in the second, "opened" attends to "student". Similar nearby-token patterns are visible elsewhere in the matrices, suggesting a general preference for local context to the left rather than a head dedicated exclusively to the grammatical subject of a verb. This interpretation is limited to the sentences examined.

Example Sentences:
- The little dog chased the [MASK].
- The young student opened the [MASK].
